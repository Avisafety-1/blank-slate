/**
 * Simple test to verify HMAC authentication is working
 */

const safeskyAuth = require('./index');
const http = require('http');

const API_KEY = 'YOUR_SAFESKY_API_KEY_HERE';

console.log('Testing HMAC Authentication...\n');

// Test GET request (no body reading issue)
const method = 'GET';
const url = 'https://sandbox-public-api.safesky.app/v1/uav?lat=50.6970&lng=4.3908&rad=20000';

const authHeaders = safeskyAuth.generateAuthHeaders(API_KEY, method, url);

console.log('Generated Headers:');
console.log(JSON.stringify(authHeaders, null, 2));
console.log('\nMaking request to:', url);
console.log();

const urlObj = new URL(url);
const options = {
    hostname: urlObj.hostname,
    port: urlObj.port || 8080,
    path: urlObj.pathname + urlObj.search,
    method: method,
    headers: {
        ...authHeaders,
        'Content-Type': 'application/json'
    }
};

const req = http.request(options, (res) => {
    console.log(`✅ Status: ${res.statusCode}`);

    if (res.statusCode === 200) {
        console.log('✅ Authentication successful!');
    } else {
        console.log('❌ Authentication failed');
    }

    let data = '';
    res.on('data', (chunk) => {
        data += chunk;
    });

    res.on('end', () => {
        console.log('\nResponse:');
        try {
            console.log(JSON.stringify(JSON.parse(data), null, 2));
        } catch (e) {
            console.log(data);
        }
    });
});

req.on('error', (e) => {
    console.error(`❌ Request error: ${e.message}`);
});

req.end();
