/**
 * SafeSky HMAC Authentication SDK for Node.js
 * 
 * This library provides functions to generate HMAC signatures for SafeSky API requests.
 * Partners can use this to authenticate their API requests.
 * 
 * @module safesky-hmac-auth
 */

const crypto = require('crypto');

/**
 * Derives the KID (Key Identifier) from an API key
 * KID = base64url(SHA256("kid:" + api_key)[0:16])
 * 
 * @param {string} apiKey - The SafeSky API key (e.g., ssk_live_...)
 * @returns {string} The derived KID in base64url format
 */
function deriveKid(apiKey) {
    const hash = crypto.createHash('sha256');
    hash.update('kid:' + apiKey);
    const digest = hash.digest();

    // Take first 16 bytes
    const first16Bytes = digest.slice(0, 16);

    // Convert to base64url (base64 with URL-safe characters)
    return first16Bytes.toString('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=/g, '');
}

/**
 * Derives the HMAC signing key from an API key using HKDF-SHA256
 * 
 * @param {string} apiKey - The SafeSky API key
 * @returns {Buffer} The derived HMAC key (32 bytes)
 */
function deriveHmacKey(apiKey) {
    const salt = 'safesky-hmac-salt-v1';
    const info = 'auth-v1';
    const length = 32;

    // HKDF Extract: PRK = HMAC-SHA256(salt, apiKey)
    const prk = crypto.createHmac('sha256', salt).update(apiKey).digest();

    // HKDF Expand
    let okm = Buffer.alloc(0);
    let previous = Buffer.alloc(0);

    for (let i = 0; i < Math.ceil(length / 32); i++) {
        const hmac = crypto.createHmac('sha256', prk);
        hmac.update(previous);
        hmac.update(info);
        hmac.update(Buffer.from([i + 1]));
        previous = hmac.digest();
        okm = Buffer.concat([okm, previous]);
    }

    return okm.slice(0, length);
}

/**
 * Builds the canonical request string for HMAC signature
 * 
 * @param {string} method - HTTP method (GET, POST, etc.)
 * @param {string} path - Request path (e.g., /v1/uav)
 * @param {string} queryString - Query string without leading '?' (e.g., lat=50.6970&lng=4.3908)
 * @param {string} host - Host header value (e.g., api.safesky.app)
 * @param {string} timestamp - ISO8601 timestamp (X-SS-Date header)
 * @param {string} nonce - Unique nonce (X-SS-Nonce header)
 * @param {string} body - Request body (empty string for GET requests)
 * @returns {string} The canonical request string
 */
function buildCanonicalRequest(method, path, queryString, host, timestamp, nonce, body) {
    // Canonical headers (must be lowercase and sorted)
    const canonicalHeaders = [
        `host:${host}`,
        `x-ss-date:${timestamp}`,
        `x-ss-nonce:${nonce}`
    ].join('\n');

    // Hash the body
    const bodyHash = crypto.createHash('sha256').update(body || '').digest('hex');

    // Build canonical request with empty line before body hash
    return [
        method.toUpperCase(),
        path,
        queryString || '',
        canonicalHeaders,
        '',  // Empty line for signed headers list (or separator)
        bodyHash
    ].join('\n');
}

/**
 * Generates HMAC-SHA256 signature for the canonical request
 * 
 * @param {string} canonicalRequest - The canonical request string
 * @param {Buffer} hmacKey - The derived HMAC signing key
 * @returns {string} The signature in base64 format
 */
function generateSignature(canonicalRequest, hmacKey) {
    const hmac = crypto.createHmac('sha256', hmacKey);
    hmac.update(canonicalRequest);
    return hmac.digest('base64');
}

/**
 * Generates a cryptographically secure nonce (UUID v4 format)
 * 
 * @returns {string} A UUID v4 nonce
 */
function generateNonce() {
    return crypto.randomUUID();
}

/**
 * Generates the current timestamp in ISO8601 format
 * 
 * @returns {string} ISO8601 timestamp (e.g., 2025-11-12T14:30:00.123Z)
 */
function generateTimestamp() {
    return new Date().toISOString();
}

/**
 * Generates all HMAC authentication headers for a SafeSky API request
 * 
 * @param {string} apiKey - The SafeSky API key
 * @param {string} method - HTTP method (GET, POST, etc.)
 * @param {string} url - Full URL (e.g., https://sandbox-public-api.safesky.app/v1/uav?lat=50.6970)
 * @param {string} [body=''] - Request body (for POST/PUT requests)
 * @returns {Object} An object containing all required headers
 * 
 * @example
 * const headers = generateAuthHeaders(
 *   'YOUR_SAFESKY_API_KEY_HERE',
 *   'GET',
 *   'https://sandbox-public-api.safesky.app/v1/uav?lat=50.6970&lng=4.3908'
 * );
 * 
 * // Returns:
 * // {
 * //   'Authorization': 'SS-HMAC Credential=bIIYYl7FmDhxl2Az6S6Whg/v1, SignedHeaders=host;x-ss-date;x-ss-nonce, Signature=abc123...',
 * //   'X-SS-Date': '2025-11-12T14:30:00Z',
 * //   'X-SS-Nonce': '550e8400-e29b-41d4-a716-446655440000',
 * //   'X-SS-Alg': 'SS-HMAC-SHA256-V1'
 * // }
 */
function generateAuthHeaders(apiKey, method, url, body = '') {
    // Parse URL
    const urlObj = new URL(url);
    const host = urlObj.host;
    const path = urlObj.pathname;
    const queryString = urlObj.search.slice(1); // Remove leading '?'

    // Generate timestamp and nonce
    const timestamp = generateTimestamp();
    const nonce = generateNonce();

    // Derive KID and HMAC key
    const kid = deriveKid(apiKey);
    const hmacKey = deriveHmacKey(apiKey);

    // Build canonical request
    const canonicalRequest = buildCanonicalRequest(
        method,
        path,
        queryString,
        host,
        timestamp,
        nonce,
        body
    );

    // Generate signature
    const signature = generateSignature(canonicalRequest, hmacKey);

    // Build Authorization header
    const authorization = `SS-HMAC Credential=${kid}/v1, SignedHeaders=host;x-ss-date;x-ss-nonce, Signature=${signature}`;

    return {
        'Authorization': authorization,
        'X-SS-Date': timestamp,
        'X-SS-Nonce': nonce,
        'X-SS-Alg': 'SS-HMAC-SHA256-V1'
    };
}

module.exports = {
    deriveKid,
    deriveHmacKey,
    buildCanonicalRequest,
    generateSignature,
    generateNonce,
    generateTimestamp,
    generateAuthHeaders
};
