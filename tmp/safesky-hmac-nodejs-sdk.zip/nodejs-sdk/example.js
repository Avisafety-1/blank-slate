/**
 * SafeSky HMAC Authentication - Usage Examples
 * 
 * This file demonstrates how to use the SafeSky HMAC authentication SDK
 * to make authenticated API requests.
 */

const safeskyAuth = require('./safesky-hmac-auth');
const https = require('https');

// Your SafeSky API key - REPLACE WITH YOUR ACTUAL API KEY
const API_KEY = 'YOUR_SAFESKY_API_KEY_HERE';

// API endpoints - choose one:
const API_ENDPOINT = 'https://sandbox-public-api.safesky.app';  // Sandbox environment (default)
// const API_ENDPOINT = 'https://public-api.safesky.app';       // Production environment

/**
 * Example 1: Simple GET request
 */
function exampleGetRequest() {
    console.log('=== Example 1: GET nearby aircraft ===\n');

    const method = 'GET';
    const url = `${API_ENDPOINT}/v1/uav?lat=50.6970&lng=4.3908&rad=20000`;

    // Generate authentication headers
    const authHeaders = safeskyAuth.generateAuthHeaders(API_KEY, method, url);

    console.log('Generated Headers:');
    console.log(JSON.stringify(authHeaders, null, 2));
    console.log('\n');

    // Make the request
    const urlObj = new URL(url);
    const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || 443,
        path: urlObj.pathname + urlObj.search,
        method: method,
        headers: {
            ...authHeaders,
            'Content-Type': 'application/json'
        }
    };

    const req = https.request(options, (res) => {
        console.log(`Status: ${res.statusCode}`);
        console.log(`Headers: ${JSON.stringify(res.headers, null, 2)}\n`);

        let data = '';
        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Response Body:');
            try {
                console.log(JSON.stringify(JSON.parse(data), null, 2));
            } catch (e) {
                console.log(data);
            }
            console.log('\n' + '='.repeat(60) + '\n');

            // Run next example
            examplePostRequest();
        });
    });

    req.on('error', (e) => {
        console.error(`Request error: ${e.message}`);
        console.error(`Error code: ${e.code}`);
        console.error(`Full error:`, e);
        console.log('\n' + '='.repeat(60) + '\n');
        // Continue to next example even on error
        examplePostRequest();
    });

    req.end();
}

/**
 * Example 2: POST UAV position
 */
function examplePostRequest() {
    console.log('=== Example 2: POST UAV position ===\n');

    const method = 'POST';
    const url = `${API_ENDPOINT}/v1/uav`;

    const body = JSON.stringify([
        {
            "id": "my_uav_001",
            "altitude": 110,
            "latitude": 50.69378,
            "longitude": 4.39201,
            "last_update": Math.floor(Date.now() / 1000),
            "status": "AIRBORNE",
            "call_sign": "Test UAV",
            "ground_speed": 10,
            "course": 250,
            "vertical_rate": 5
        }
    ]);

    // Generate authentication headers (pass the body for POST)
    const authHeaders = safeskyAuth.generateAuthHeaders(API_KEY, method, url, body);

    console.log('Generated Headers:');
    console.log(JSON.stringify(authHeaders, null, 2));
    console.log('\nRequest Body:');
    console.log(JSON.stringify(JSON.parse(body), null, 2));
    console.log('\n');

    // Make the request
    const urlObj = new URL(url);
    const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || 443,
        path: urlObj.pathname,
        method: method,
        headers: {
            ...authHeaders,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body)
        }
    };

    const req = https.request(options, (res) => {
        console.log(`Status: ${res.statusCode}`);

        let data = '';
        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Response Body:');
            try {
                console.log(JSON.stringify(JSON.parse(data), null, 2));
            } catch (e) {
                console.log(data);
            }
            console.log('\n' + '='.repeat(60) + '\n');

            // Run next example
            examplePostWithQueryParams();
        });
    });

    req.on('error', (e) => {
        console.error(`Request error: ${e.message}`);
        console.error(`Error code: ${e.code}`);
        console.error(`Full error:`, e);
        console.log('\n' + '='.repeat(60) + '\n');
        examplePostWithQueryParams();
    });

    req.write(body);
    req.end();
}

/**
 * Example 3: POST UAV with query parameter (return nearby traffic)
 */
function examplePostWithQueryParams() {
    console.log('=== Example 3: POST UAV with return_nearby_traffic ===\n');

    const method = 'POST';
    const url = `${API_ENDPOINT}/v1/uav?return_nearby_traffic=true`;

    const body = JSON.stringify([
        {
            "id": "my_uav_002",
            "altitude": 150,
            "latitude": 50.69378,
            "longitude": 4.39201,
            "last_update": Math.floor(Date.now() / 1000),
            "status": "AIRBORNE",
            "call_sign": "Traffic UAV",
            "ground_speed": 15,
            "course": 180,
            "vertical_rate": 0
        }
    ]);

    // Generate authentication headers (URL includes query params)
    const authHeaders = safeskyAuth.generateAuthHeaders(API_KEY, method, url, body);

    console.log('Generated Headers:');
    console.log(JSON.stringify(authHeaders, null, 2));
    console.log('\nRequest Body:');
    console.log(JSON.stringify(JSON.parse(body), null, 2));
    console.log('\n');

    // Make the request
    const urlObj = new URL(url);
    const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || 443,
        path: urlObj.pathname + urlObj.search,
        method: method,
        headers: {
            ...authHeaders,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body)
        }
    };

    const req = https.request(options, (res) => {
        console.log(`Status: ${res.statusCode}`);

        let data = '';
        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Response Body (nearby traffic included):');
            try {
                console.log(JSON.stringify(JSON.parse(data), null, 2));
            } catch (e) {
                console.log(data);
            }
            console.log('\n' + '='.repeat(60) + '\n');

            // Run next example
            examplePostAdvisory();
        });
    });

    req.on('error', (e) => {
        console.error(`Request error: ${e.message}`);
        console.error(`Error code: ${e.code}`);
        console.error(`Full error:`, e);
        console.log('\n' + '='.repeat(60) + '\n');
        examplePostAdvisory();
    });

    req.write(body);
    req.end();
}

/**
 * Example 4: POST advisory (GeoJSON polygon)
 */
function examplePostAdvisory() {
    console.log('=== Example 4: POST advisory (GeoJSON) ===\n');

    const method = 'POST';
    const url = `${API_ENDPOINT}/v1/advisory`;

    const timestamp = Math.floor(Date.now() / 1000);
    const body = JSON.stringify({
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {
                    "id": "my_advisory_id1",
                    "max_altitude": 111,
                    "last_update": timestamp,
                    "call_sign": "Advisory test with polygon",
                    "remarks": "Inspection powerlines"
                },
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [
                        [
                            [4.3948, 50.6831],
                            [4.3952, 50.6832],
                            [4.3958, 50.6835],
                            [4.3963, 50.6838],
                            [4.4072, 50.6902],
                            [4.4075, 50.6903],
                            [4.4081, 50.6905],
                            [4.4085, 50.6907],
                            [4.4092, 50.6910],
                            [4.4096, 50.6912],
                            [4.4103, 50.6915],
                            [4.4106, 50.6917],
                            [4.4110, 50.6920],
                            [4.4113, 50.6922],
                            [4.4116, 50.6925],
                            [4.4118, 50.6927],
                            [4.4120, 50.6930],
                            [4.4121, 50.6932],
                            [4.4120, 50.6935],
                            [4.4118, 50.6937],
                            [4.4115, 50.6940],
                            [4.3750, 50.7150],
                            [4.3748, 50.7153],
                            [4.3746, 50.7155],
                            [4.3742, 50.7158],
                            [4.3740, 50.7160],
                            [4.3735, 50.7162],
                            [4.3733, 50.7163],
                            [4.3435, 50.7280],
                            [4.3432, 50.7281],
                            [4.3426, 50.7283],
                            [4.3423, 50.7284],
                            [4.3416, 50.7286],
                            [4.3412, 50.7287],
                            [4.3405, 50.7288],
                            [4.3402, 50.7289],
                            [4.3395, 50.7290],
                            [4.3392, 50.7290],
                            [4.3385, 50.7291],
                            [4.3382, 50.7291],
                            [4.3376, 50.7290],
                            [4.3373, 50.7289],
                            [4.3367, 50.7287],
                            [4.3365, 50.7286],
                            [4.3360, 50.7284],
                            [4.3358, 50.7282],
                            [4.3200, 50.7210],
                            [4.3195, 50.7208],
                            [4.3193, 50.7207],
                            [4.3189, 50.7205],
                            [4.3187, 50.7203],
                            [4.3185, 50.7200],
                            [4.3184, 50.7198],
                            [4.3182, 50.7195],
                            [4.3181, 50.7193],
                            [4.3948, 50.6831]
                        ]
                    ]
                }
            },
            {
                "type": "Feature",
                "properties": {
                    "id": "my_advisory_id2",
                    "max_altitude": 150,
                    "max_distance": 500,
                    "last_update": timestamp,
                    "call_sign": "Advisory test with a point",
                    "remarks": "Inspection rails"
                },
                "geometry": {
                    "type": "Point",
                    "coordinates": [4.4, 50.7]
                }
            }
        ]
    });

    // Generate authentication headers
    const authHeaders = safeskyAuth.generateAuthHeaders(API_KEY, method, url, body);

    console.log('Generated Headers:');
    console.log(JSON.stringify(authHeaders, null, 2));
    console.log('\nRequest Body (GeoJSON):');
    console.log(JSON.stringify(JSON.parse(body), null, 2));
    console.log('\n');

    // Make the request
    const urlObj = new URL(url);
    const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || 443,
        path: urlObj.pathname,
        method: method,
        headers: {
            ...authHeaders,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body)
        }
    };

    const req = https.request(options, (res) => {
        console.log(`Status: ${res.statusCode}`);

        let data = '';
        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Response Body:');
            try {
                console.log(JSON.stringify(JSON.parse(data), null, 2));
            } catch (e) {
                console.log(data);
            }
            console.log('\n' + '='.repeat(60) + '\n');

            // Run next example
            exampleManualSteps();
        });
    });

    req.on('error', (e) => {
        console.error(`Request error: ${e.message}`);
        console.error(`Error code: ${e.code}`);
        console.error(`Full error:`, e);
        console.log('\n' + '='.repeat(60) + '\n');
        exampleManualSteps();
    });

    req.write(body);
    req.end();
}

/**
 * Example 5: Step-by-step manual authentication
 * This shows all the individual steps if you need more control
 */
function exampleManualSteps() {
    console.log('=== Example 5: Manual step-by-step authentication ===\n');

    const apiKey = API_KEY;

    // Step 1: Derive KID
    const kid = safeskyAuth.deriveKid(apiKey);
    console.log(`Step 1 - Derived KID: ${kid}`);

    // Step 2: Derive HMAC key
    const hmacKey = safeskyAuth.deriveHmacKey(apiKey);
    console.log(`Step 2 - Derived HMAC Key: ${hmacKey.toString('hex').substring(0, 32)}...`);

    // Step 3: Generate timestamp and nonce
    const timestamp = safeskyAuth.generateTimestamp();
    const nonce = safeskyAuth.generateNonce();
    console.log(`Step 3 - Timestamp: ${timestamp}`);
    console.log(`Step 3 - Nonce: ${nonce}`);

    // Step 4: Build canonical request
    const method = 'GET';
    const path = '/v1/uav';
    const queryString = 'lat=50.6970&lng=4.3908';
    // const host = 'localhost';                                      // For local development
    const host = 'sandbox-public-api.safesky.app';                   // Sandbox environment (default)
    // const host = 'public-api.safesky.app';                        // Production environment
    const body = '';

    const canonicalRequest = safeskyAuth.buildCanonicalRequest(
        method, path, queryString, host, timestamp, nonce, body
    );
    console.log('\nStep 4 - Canonical Request:');
    console.log(canonicalRequest);

    // Step 5: Generate signature
    const signature = safeskyAuth.generateSignature(canonicalRequest, hmacKey);
    console.log(`\nStep 5 - Signature: ${signature}`);

    // Step 6: Build Authorization header
    const authorization = `SS-HMAC Credential=${kid}/v1, SignedHeaders=host;x-ss-date;x-ss-nonce, Signature=${signature}`;
    console.log(`\nStep 6 - Authorization Header:\n${authorization}`);

    console.log('\n' + '='.repeat(60) + '\n');
}

// Run examples
console.log('\n' + '='.repeat(60));
console.log('SafeSky HMAC Authentication - Examples');
console.log('='.repeat(60) + '\n');

exampleGetRequest();
