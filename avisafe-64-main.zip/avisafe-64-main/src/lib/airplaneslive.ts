export const airplanesLiveConfig = {
  baseUrl: "https://api.airplanes.live/v2",
};
